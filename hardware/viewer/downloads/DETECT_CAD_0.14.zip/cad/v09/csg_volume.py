"""Measure CSG solid volume without mistaking planar contact sheets for solids.

CGAL can export exact touching faces as open planar STL components. Applying
the tetrahedron volume formula to an open sheet gives a coordinate-dependent
false volume. Discard only components planar within STL precision (1e-4 mm); require every
remaining component to have closed, consistently oriented edges.
"""
import collections,math
def solid_volume(tris):
    def dot(a,b):return sum(x*y for x,y in zip(a,b))
    def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
    def sub(a,b):return [x-y for x,y in zip(a,b)]
    adjacent=collections.defaultdict(list)
    for i,t in enumerate(tris):
        for v in t:adjacent[tuple(v)].append(i)
    unseen=set(range(len(tris)));total=0.;sheets=0
    while unseen:
        root=unseen.pop();queue=[root];ids=[root]
        while queue:
            i=queue.pop()
            for v in tris[i]:
                for j in adjacent[tuple(v)]:
                    if j in unseen:unseen.remove(j);queue.append(j);ids.append(j)
        component=[tris[i] for i in ids]
        # A contact face may be tessellated into very skinny triangles. Their
        # normals amplify the ASCII STL rounding error. Use widely separated
        # vertices to determine the plane instead of a single mesh triangle.
        points=list({tuple(v) for t in component for v in t})
        a=points[0];b=max(points,key=lambda p:math.dist(a,p))
        a=max(points,key=lambda p:math.dist(b,p))
        c=max(points,key=lambda p:math.hypot(*cross(sub(b,a),sub(p,a))))
        n=cross(sub(b,a),sub(c,a));length=math.hypot(*n)
        if length>1e-10:
            # Fit a plane to all vertices; the dominant normal coordinate is
            # a well-conditioned dependent variable (no third-party library).
            axis=max(range(3),key=lambda k:abs(n[k]));u,v=[k for k in range(3) if k!=axis]
            mean=[sum(p[k] for p in points)/len(points) for k in range(3)]
            ds=[sub(p,mean) for p in points]
            uu=sum(d[u]*d[u] for d in ds);vv=sum(d[v]*d[v] for d in ds)
            uv=sum(d[u]*d[v] for d in ds);uw=sum(d[u]*d[axis] for d in ds);vw=sum(d[v]*d[axis] for d in ds)
            det=uu*vv-uv*uv
            if det>1e-16:
                n=[0.,0.,0.];n[axis]=1.;n[u]=-(uw*vv-vw*uv)/det;n[v]=-(vw*uu-uw*uv)/det
                a=mean;length=math.hypot(*n)
        if length<1e-10 or max(abs(dot(sub(v,a),n))/length for t in component for v in t)<1e-4:
            sheets+=1;continue
        edges=collections.Counter();directed=collections.Counter()
        for t in component:
            for u,v in zip(t,t[1:]+t[:1]):
                u=tuple(u);v=tuple(v);edges[tuple(sorted([u,v]))]+=1;directed[(u,v)]+=1
        if any(count!=2 for count in edges.values()) or any(directed[(u,v)]!=directed[(v,u)] for u,v in edges):
            raise RuntimeError('Non-planar open/nonmanifold CSG result; cannot certify its volume')
        total+=abs(sum(dot(a,cross(b,c)) for a,b,c in component)/6)
    return total,sheets
