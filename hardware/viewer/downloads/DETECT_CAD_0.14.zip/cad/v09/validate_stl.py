#!/usr/bin/env python3
"""Small dependency-free STL sanity checker for the generated OpenSCAD meshes."""

from __future__ import annotations

import collections
import pathlib
import re
import sys


VERTEX = re.compile(
    rb"\bvertex\s+([-+0-9.eE]+)\s+([-+0-9.eE]+)\s+([-+0-9.eE]+)"
)


def key(point: tuple[float, float, float]) -> tuple[int, int, int]:
    return tuple(round(value * 1_000_000) for value in point)


def inspect(path: pathlib.Path) -> tuple[bool, str]:
    data = path.read_bytes()
    vertices = [tuple(map(float, match.groups())) for match in VERTEX.finditer(data)]
    if not vertices or len(vertices) % 3:
        return False, f"{path.name}: invalid or unsupported STL"

    edges: collections.Counter[tuple[tuple[int, int, int], tuple[int, int, int]]] = collections.Counter()
    unique: set[tuple[int, int, int]] = set()
    for index in range(0, len(vertices), 3):
        tri = [key(vertex) for vertex in vertices[index : index + 3]]
        unique.update(tri)
        for a, b in ((tri[0], tri[1]), (tri[1], tri[2]), (tri[2], tri[0])):
            edges[tuple(sorted((a, b)))] += 1

    nonmanifold = sum(1 for count in edges.values() if count != 2)
    xs, ys, zs = zip(*vertices)
    dims = (max(xs) - min(xs), max(ys) - min(ys), max(zs) - min(zs))
    ok = nonmanifold == 0
    return ok, (
        f"{path.name}: triangles={len(vertices)//3}, vertices={len(unique)}, "
        f"bounds={dims[0]:.2f}x{dims[1]:.2f}x{dims[2]:.2f} mm, "
        f"nonmanifold_edges={nonmanifold}"
    )


def main() -> int:
    root = pathlib.Path(__file__).resolve().parent / "stl"
    files = sorted(path for path in root.glob("*.stl") if path.name != "assembly_reference.stl")
    if not files:
        print("No STL files found", file=sys.stderr)
        return 2

    failures = 0
    for path in files:
        ok, message = inspect(path)
        print(message)
        failures += not ok
    print(f"Checked {len(files)} files; failures={failures}")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
