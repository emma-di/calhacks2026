#!/usr/bin/env python3
"""Independent ASCII-STL audit: degeneracy, watertightness, orientation, volume."""

from __future__ import annotations

import math
import sys
from collections import Counter, defaultdict
from pathlib import Path


def key(v: tuple[float, float, float]) -> tuple[float, float, float]:
    return tuple(round(c, 6) for c in v)


def sub(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def cross(a, b):
    return (
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    )


def dot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def load(path: Path):
    verts = []
    for line in path.read_text(errors="strict").splitlines():
        words = line.strip().split()
        if words[:1] == ["vertex"] and len(words) == 4:
            verts.append(key(tuple(map(float, words[1:4]))))
    if not verts or len(verts) % 3:
        raise ValueError("missing or incomplete ASCII STL triangles")
    return [tuple(verts[i : i + 3]) for i in range(0, len(verts), 3)]


def audit(path: Path):
    tris = load(path)
    undirected = Counter()
    directed = Counter()
    edge_to_tris = defaultdict(list)
    area = 0.0
    volume6 = 0.0
    degenerates = 0

    for ti, (a, b, c) in enumerate(tris):
        n = cross(sub(b, a), sub(c, a))
        twice_area = math.sqrt(dot(n, n))
        if twice_area < 1e-8:
            degenerates += 1
        area += twice_area / 2.0
        volume6 += dot(a, cross(b, c))
        for u, v in ((a, b), (b, c), (c, a)):
            e = tuple(sorted((u, v)))
            undirected[e] += 1
            directed[(u, v)] += 1
            edge_to_tris[e].append(ti)

    bad_edges = sum(1 for count in undirected.values() if count != 2)
    orientation_errors = 0
    for u, v in undirected:
        if directed[(u, v)] != directed[(v, u)]:
            orientation_errors += 1

    # Count disconnected closed shells using shared-edge triangle adjacency.
    parent = list(range(len(tris)))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra

    for ids in edge_to_tris.values():
        for other in ids[1:]:
            union(ids[0], other)
    shell_counts = Counter(find(i) for i in range(len(tris)))
    shells = len(shell_counts)

    volume = abs(volume6) / 6.0
    allowed_shells = 1
    ok = (
        not (degenerates or bad_edges or orientation_errors)
        and volume > 1e-6
        and shells == allowed_shells
    )
    shell_detail = ""
    if shells > 1:
        bounds_by_shell = {}
        for i, tri in enumerate(tris):
            root = find(i)
            pts = bounds_by_shell.setdefault(root, [])
            pts.extend(tri)
        shell_bounds = []
        for root, pts in bounds_by_shell.items():
            lo = tuple(min(p[j] for p in pts) for j in range(3))
            hi = tuple(max(p[j] for p in pts) for j in range(3))
            shell_bounds.append((shell_counts[root], lo, hi))
        shell_bounds.sort(reverse=True)
        shell_detail = ", shell_bounds=" + repr(shell_bounds)

    print(
        f"{path.name}: ok={str(ok).lower()}, triangles={len(tris)}, "
        f"shells={shells}, degenerate={degenerates}, bad_edges={bad_edges}, "
        f"orientation_errors={orientation_errors}, area={area:.1f} mm^2, "
        f"volume={volume:.1f} mm^3"
        + (f", shell_triangles={sorted(shell_counts.values(), reverse=True)}" if shells > 1 else "")
        + shell_detail
    )
    return ok


def main():
    folder = Path(__file__).with_name("stl")
    paths = sorted(path for path in folder.glob("*.stl") if path.name != "assembly_reference.stl")
    failures = [path for path in paths if not audit(path)]
    print(f"Independently audited {len(paths)} files; failures={len(failures)}")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
