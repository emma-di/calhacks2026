#!/usr/bin/env python3
"""Export and audit the four DETECT 0.14 prints and update the viewer."""
from pathlib import Path
import ast, base64, concurrent.futures, hashlib, importlib.util, json, math, re, shutil, struct, subprocess, sys

ROOT=Path(__file__).resolve().parent
WEB=ROOT.parents[1]/'site/soundcompass-visualizer/dist'
PRINTS=['body','cover','mic_left','mic_right']
REFERENCES=['pi','gpio_plugs','gpio_tall','hook_insertion','hook_detail','hook_frame','hook_screws','head_keepout','oled','oled_fit_gauge','oled_focus_near','oled_focus_far','screen','pixels','oled_plug','mirror','lens','combiner','frame','spectacle_lenses','eye','microphones','mic_stacks','mic_insertion','usb_plug','wires','fasteners','rays']

def fingerprint():
    return hashlib.sha256((ROOT/'DETECT.scad').read_bytes()+(ROOT/'parameters.scad').read_bytes()).hexdigest()

def parameters():
    text=(ROOT/'parameters.scad').read_text()
    out={}
    for key,value in re.findall(r'^([\w]+)\s*=\s*([^;]+);',text,re.M):
        try: out[key]=ast.literal_eval(value.strip())
        except (ValueError,SyntaxError): pass
    return out

def export(item):
    reference=item.startswith('ref_')
    dest=ROOT/('reference' if reference else 'stl')/(item+'.stl')
    digest=fingerprint(); stamp=dest.with_suffix('.sha256')
    if dest.exists() and stamp.exists() and stamp.read_text()==digest:
        return dest
    result=subprocess.run(['openscad','-o',str(dest),'-D',f'part="{item}"',str(ROOT/'DETECT.scad')],capture_output=True,text=True)
    # OpenSCAD 2021 occasionally emits a conservative CGAL "may not be a
    # valid 2-manifold" warning for solids with captive nut cavities. The two
    # independent post-export mesh audits below are authoritative here.
    if result.returncode or 'ERROR:' in result.stderr:
        raise RuntimeError(item+':\n'+result.stderr)
    if 'WARNING:' in result.stderr: print('OpenSCAD warning queued for independent audit:',item,flush=True)
    if fingerprint()!=digest: raise RuntimeError('Source changed during export: '+item)
    stamp.write_text(digest)
    print('Exported',item,flush=True)
    return dest

def triangles(path):
    pts=[tuple(map(float,line.split()[1:])) for line in path.read_text().splitlines() if line.strip().startswith('vertex ')]
    return [pts[i:i+3] for i in range(0,len(pts),3)]

def packed(path,subset=None):
    tris=triangles(path) if subset is None else subset
    values=[]
    for a,b,c in tris:
        u=[b[i]-a[i] for i in range(3)]; v=[c[i]-a[i] for i in range(3)]
        n=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]]
        length=math.hypot(*n) or 1; n=[x/length for x in n]
        for point in (a,b,c): values.extend([*point,*n])
    return {'data':base64.b64encode(struct.pack(f'<{len(values)}f',*values)).decode(),'triangles':len(tris),'bytes':path.stat().st_size}

def node(identifier,mesh,color,translate=(0,0,0),rotate=(0,0,0),**extra):
    return {'id':identifier,'mesh':mesh,'color':color,'translate':translate,'rotate':rotate,**extra}

def audit_meshes():
    sys.path.insert(0,str(ROOT.parent/'v09'))
    for filename in ('validate_stl.py','audit_mesh_geometry.py'):
        spec=importlib.util.spec_from_file_location('audit_'+filename.replace('.','_'),ROOT.parent/'v09'/filename)
        module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
        for name in PRINTS:
            path=ROOT/'stl'/(name+'.stl')
            if hasattr(module,'audit'): ok=module.audit(path)
            else: ok,message=module.inspect(path); print(message)
            if not ok: raise RuntimeError(f'{filename} rejected {name}')

def main():
    for folder in ('stl','reference'): (ROOT/folder).mkdir(parents=True,exist_ok=True)
    items=PRINTS+['ref_'+name for name in REFERENCES]
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        list(pool.map(export,items))
    audit_meshes()
    if '--export-only' in sys.argv: return

    checked=json.loads((ROOT/'CHECKS.json').read_text())
    if checked.get('source_sha256')!=fingerprint():
        raise RuntimeError('Run check.py on the current CAD before publishing the viewer')
    optics_checked=json.loads((ROOT/'OPTICAL_CHECK.json').read_text())
    if optics_checked.get('source_sha256')!=fingerprint():
        raise RuntimeError('Run optical_check.py on the current CAD before publishing the viewer')

    meshes={name:packed(ROOT/'stl'/(name+'.stl')) for name in PRINTS}
    meshes.update({'ref_'+name:packed(ROOT/'reference'/('ref_'+name+'.stl')) for name in REFERENCES})
    p=parameters()
    mic_source=ROOT/'reference/ref_microphones.stl'
    fastener_source=ROOT/'reference/ref_fasteners.stl'
    mic_local=[[[x-p['mic_x'],y,z] for x,y,z in tri] for tri in triangles(mic_source) if all(v[1]>0 for v in tri)]
    mic_metal=[[[x-p['mic_x'],y,z] for x,y,z in tri] for tri in triangles(fastener_source) if all(v[0]>100 and v[1]>0 for v in tri)]
    meshes['detail_mic']=packed(mic_source,mic_local)
    stack_source=ROOT/'reference/ref_mic_stacks.stl'
    stack_local=[[[x-p['mic_x'],y,z] for x,y,z in tri] for tri in triangles(stack_source) if all(v[1]>0 for v in tri)]
    meshes['detail_mic_stack']=packed(stack_source,stack_local)
    meshes['detail_mic_metal']=packed(fastener_source,mic_metal)
    # Dark charcoal keeps a black-material appearance while remaining legible
    # against the viewer's near-black background.
    black=[.22,.23,.24,1]
    nodes=[
        node('body','body',black),node('cover','cover',black,lid=True),
        node('mic_right','mic_right',black,[p['mic_x'],0,0]),
        node('mic_left','mic_left',black,[p['mic_x'],-134,0],[0,0,180]),
    ]
    colors={
        'pi':[.16,.54,.30,1],'gpio_plugs':[.13,.16,.18,1],'oled':[.13,.19,.25,1],
        'screen':[.04,.06,.07,1],'pixels':[.8,.98,1,1],'oled_plug':[.13,.16,.18,1],
        'mirror':[.94,.96,.98,1],'lens':[.4,.83,1,.42],'combiner':[.35,.87,1,.42],
        'frame':[.38,.42,.44,1],'spectacle_lenses':[.65,.8,.9,.12],'eye':[.6,.7,.74,.6],
        'microphones':[.16,.38,.29,1],'mic_stacks':[.65,.7,.75,.25],'usb_plug':[.14,.16,.18,1],'wires':[.82,.28,.2,1],'fasteners':[.62,.66,.68,1],'rays':[1,.83,.25,1],
    }
    nodes += [node(name,'ref_'+name,color,reference=True) for name,color in colors.items()]
    labels={
        'body':'Body + integral hanging hook','cover':'Stepped lid + raised wiring hood',
        'mic_left':'Left drop-in mic carrier','mic_right':'Right drop-in mic carrier',
    }
    checked=json.loads((ROOT/'CHECKS.json').read_text()) if (ROOT/'CHECKS.json').exists() else None
    measurements={
        'optics':{'oled_to_mirror_chief_ray_mm':math.dist(p['O'],p['M']),'mirror_to_focusing_lens_chief_ray_mm':math.dist(p['M'],p['L']),'folded_object_distance_mm':36,'focus_range_mm':[33,39]},
        'wiring':{'oled_front_exit_mm':p['oled_front_exit'],'mic_rear_exit_mm':p['mic_rear_exit'],'mic_bundle_d_mm':p['mic_bundle_d'],'oled_bundle_d_mm':p['oled_bundle_d'],'plug_headroom_mm':p['gpio_hood_z']-p['pi_origin'][2]-p['pi_t']-p['gpio_plug_height']},
        'piece_count':4,
        'fit_status':'PARTIAL MEASUREMENTS RECEIVED; DRY FIT PENDING',
    }
    if checked: measurements['verified']=checked
    detail_nodes={
        'body':[node('pi','ref_pi',colors['pi']),node('gpio','ref_gpio_plugs',colors['gpio_plugs']),node('oled','ref_oled',colors['oled']),node('mirror','ref_mirror',colors['mirror']),node('lens','ref_lens',colors['lens']),node('combiner','ref_combiner',colors['combiner'])],
        'cover':[node('pi','ref_pi',colors['pi']),node('gpio','ref_gpio_plugs',colors['gpio_plugs']),node('oled','ref_oled',colors['oled']),node('mirror','ref_mirror',colors['mirror']),node('lens','ref_lens',colors['lens']),node('combiner','ref_combiner',colors['combiner'])],
        'mic_left':[node('pcb','detail_mic',colors['microphones']),node('pin_depth','detail_mic_stack',colors['mic_stacks']),node('hardware','detail_mic_metal',colors['fasteners'])],
        'mic_right':[node('pcb','detail_mic',colors['microphones']),node('pin_depth','detail_mic_stack',colors['mic_stacks']),node('hardware','detail_mic_metal',colors['fasteners'])],
    }
    payload={'version':'0.14','source_sha256':fingerprint(),'meshes':meshes,'nodes':nodes,'prints':PRINTS,'labels':labels,'parameters':p,'measurements':measurements,'detail_nodes':detail_nodes}
    (WEB/'cad-data.js').write_text('window.DETECT_DATA='+json.dumps(payload,separators=(',',':'))+';\n')

    stl_folder=WEB/'assets/stl-v14'; source_folder=WEB/'assets/source-v14'; download_folder=WEB/'downloads'
    for folder in (stl_folder,source_folder,download_folder): folder.mkdir(parents=True,exist_ok=True)
    for name in PRINTS: shutil.copy2(ROOT/'stl'/(name+'.stl'),stl_folder/(name+'.stl'))
    for name in ('DETECT.scad','parameters.scad','README.md','MEASURED_FIT.md','CHECKS.json','OPTICAL_CHECK.json'): shutil.copy2(ROOT/name,source_folder/name)
    print('Viewer updated from four audited v0.14 print meshes.',flush=True)

if __name__=='__main__': main()

