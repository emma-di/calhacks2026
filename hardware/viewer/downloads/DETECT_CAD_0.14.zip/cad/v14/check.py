#!/usr/bin/env python3
"""Mechanical clearance and declared-dimension checks for DETECT 0.14."""
from pathlib import Path
import ast, concurrent.futures, hashlib, importlib.util, json, math, re, subprocess

ROOT=Path(__file__).resolve().parent
NAMES=['body vs frame','body vs Pi','body vs GPIO plugs','cover vs Pi','cover vs GPIO plugs','body vs optics','cover vs optics','mic carriers vs frame','mic carriers vs PCBs','hook local side-loading path','wire routing envelopes','mic carriers vs solder/pin envelope','mic vertical insertion path','body and cover vs USB plug','body vs cover (0.02 mm seating lift)','GPIO connectors 3 mm taller','central optical path vs printed housing','rear mic slot clear gauge','front OLED slot clear gauge','housing and cables vs coarse head keepout','top arm-screw access through printed body','enlarged OLED pocket gauge']

def params():
    out={}
    for k,v in re.findall(r'^([\w]+)\s*=\s*([^;]+);',(ROOT/'parameters.scad').read_text(),re.M):
        try: out[k]=ast.literal_eval(v.strip())
        except (ValueError,SyntaxError): pass
    return out

def tris(path):
    pts=[tuple(map(float,line.split()[1:])) for line in path.read_text().splitlines() if line.strip().startswith('vertex ')]
    return [pts[i:i+3] for i in range(0,len(pts),3)]

def load_volume():
    spec=importlib.util.spec_from_file_location('csg_volume',ROOT.parent/'v09/csg_volume.py')
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module.solid_volume

def main():
    p=params(); solid_volume=load_volume(); audit=[]
    out=ROOT/'checks'; out.mkdir(exist_ok=True)
    def run_probe(item):
        index,name=item
        path=out/f'{index:02d}.stl'
        result=subprocess.run(['openscad','-o',str(path),'-D',f'probe={index}',str(ROOT/'checks.scad')],capture_output=True,text=True)
        if result.returncode or 'ERROR:' in result.stderr: raise RuntimeError(name+'\n'+result.stderr)
        volume,sheets=solid_volume(tris(path)); interference=max(0,volume-1)
        passed=interference<.04
        print(f'{name}: {interference:.5f} mm³'+(' PASS' if passed else (' FAIL' if passed is False else ' DIAGNOSTIC')))
        return {'name':name,'solid_interference_mm3':round(interference,5),'planar_contact_sheets':sheets,'passed':passed}

    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        audit=list(pool.map(run_probe,enumerate(NAMES)))

    # Pure dimensional budget checks, independent of rendered annotations.
    mic_area=math.pi*(p['mic_bundle_d']/2)**2
    oled_area=math.pi*(p['oled_bundle_d']/2)**2
    front_area=p['oled_front_exit'][0]*p['oled_front_exit'][1]
    rear_area=p['mic_rear_exit'][0]*p['mic_rear_exit'][1]
    # Conservative sampled distance between the active OLED rectangle and the
    # finite mirror rectangle at both ends of focus travel. Coordinates are
    # evaluated in the mirror's local in-plane basis and clamped to its edges.
    O=p['O']; M=p['M']; L=p['L']
    incoming=[(M[i]-O[i]) for i in range(3)]; outgoing=[(L[i]-M[i]) for i in range(3)]
    incoming=[x/math.hypot(*incoming) for x in incoming]; outgoing=[x/math.hypot(*outgoing) for x in outgoing]
    normal=[incoming[i]-outgoing[i] for i in range(3)]; normal=[x/math.hypot(*normal) for x in normal]
    inplane=[-normal[1],normal[0],0]
    def screen_mirror_gap(dx):
        best=1e9
        for iy in range(121):
            sy=O[1]-10.85+21.7*iy/120
            for iz in range(61):
                point=[O[0]+dx,sy,O[2]-5.4+10.8*iz/60]
                delta=[point[i]-M[i] for i in range(3)]
                ly=max(-p['mirror_w']/2,min(p['mirror_w']/2,sum(delta[i]*inplane[i] for i in range(3))))
                lz=max(-p['mirror_h']/2,min(p['mirror_h']/2,delta[2]))
                closest=[M[i]+inplane[i]*ly+(lz if i==2 else 0) for i in range(3)]
                best=min(best,math.dist(point,closest))
        return best
    gaps=[screen_mirror_gap(-p['oled_focus_travel']),screen_mirror_gap(p['oled_focus_travel'])]
    dimensional={
        'piece_count':4,
        'folded_object_distance_mm':math.dist(p['O'],p['M'])+math.dist(p['M'],p['L']),
        'front_oled_exit_area_mm2':front_area,'front_reserved_bundle_area_mm2':round(oled_area,2),
        'rear_mics_exit_area_mm2':rear_area,'rear_reserved_two_mic_bundles_area_mm2':round(2*mic_area,2),
        'front_area_ratio':round(front_area/oled_area,2),'rear_area_ratio':round(rear_area/(2*mic_area),2),
        'gpio_hood_cavity_height_above_lid_plane_mm':round(p['gpio_hood_z']-p['electronics_lid_z'],2),
        'actual_headroom_above_modeled_GPIO_plugs_mm':round(p['gpio_hood_z']-p['pi_origin'][2]-p['pi_t']-p['gpio_plug_height'],2),
        'mic_wire_bend_centerline_radius_mm':p['wire_bend_radius'],
        'oled_to_mirror_minimum_surface_gap_mm':round(min(gaps),2),
        'assumed_oled_board_mm':[p['oled_pcb_t'],p['oled_w'],p['oled_h']],
        'oled_pocket_envelope_mm':[p['oled_pocket_t'],p['oled_pocket_w'],p['oled_pocket_h']],
        'oled_extra_each_dimension_mm':[round(p['oled_pocket_t']-p['oled_pcb_t'],2),round(p['oled_pocket_w']-p['oled_w'],2),round(p['oled_pocket_h']-p['oled_h'],2)],
        'measured_arm_mm':[p['temple_h'],p['temple_t']],
        'hook_opening_height_mm':round(p['temple_h']+2*p['temple_fit'],3),
        'hook_internal_engagement_depth_mm':round(p['temple_t']/2+p['temple_fit']-p['hook_inner_y'],3),
        'hook_screw_entry':'top',
        'hook_underside_fasteners':False,
        'hook_top_boss_height_mm':p['hook_top_boss_h'],
        'mic_diameter_mm':p['mic_d'],
        'mic_total_depth_mm':p['mic_total_depth'],
        'mic_pin_edge_margin_assumed_mm':p['mic_pin_edge_margin'],
        'usb_plug_cross_section_mm':[p['usb_plug_w'],p['usb_plug_h']],
        'status':'PARTIAL MEASUREMENTS RECEIVED; physical dry fit and optical focus pending',
    }
    if dimensional['folded_object_distance_mm']!=36: raise RuntimeError('Folded optical path is not 36 mm')
    if dimensional['front_area_ratio']<2 or dimensional['rear_area_ratio']<2: raise RuntimeError('Wire exit area reserve below 2')
    if dimensional['actual_headroom_above_modeled_GPIO_plugs_mm']<8: raise RuntimeError('Insufficient modeled plug headroom')
    if p['mic_rear_exit'][0]<2*p['mic_bundle_d']+1: raise RuntimeError('Rear slot cannot fit two separate mic bundles side by side')
    if dimensional['oled_to_mirror_minimum_surface_gap_mm']<2.5: raise RuntimeError('OLED-to-mirror surface gap below 2.5 mm')
    if any(abs(x-1)>1e-6 for x in dimensional['oled_extra_each_dimension_mm']): raise RuntimeError('OLED pocket is not exactly 1 mm larger in all dimensions')
    if any(item['passed'] is False for item in audit): raise RuntimeError('One or more solid-clearance probes failed')
    report={'source_sha256':hashlib.sha256((ROOT/'DETECT.scad').read_bytes()+(ROOT/'parameters.scad').read_bytes()).hexdigest(),'clearance_probes':audit,'dimensions':dimensional}
    (ROOT/'CHECKS.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(dimensional,indent=2))

if __name__=='__main__': main()

