"""Geometric fold/aperture checks, not a calibrated lens or eye-box simulation."""
import hashlib, importlib.util, json, math
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def main():
    spec=importlib.util.spec_from_file_location('fit_check',ROOT/'check.py')
    m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); p=m.params()
    def sub(a,b): return [a[i]-b[i] for i in range(3)]
    def add(a,b): return [a[i]+b[i] for i in range(3)]
    def scale(a,s): return [v*s for v in a]
    def dot(a,b): return sum(x*y for x,y in zip(a,b))
    def unit(a): return scale(a,1/math.hypot(*a))
    O,M,L,C,E=[p[k] for k in ('O','M','L','C','E')]
    normal=unit(sub(unit(sub(M,O)),unit(sub(L,M))))
    along=[-normal[1],normal[0],0]
    def check_zone(w,h,pupil_radius):
        margin=1e9; rejected=0; count=0
        for dx in [-p['oled_focus_travel'],0,p['oled_focus_travel']]:
            for y in [-w/2,0,w/2]:
                for z in [-h/2,0,h/2]:
                    source=add(O,[dx,y,z])
                    for px,pz in [(0,0),(pupil_radius,0),(-pupil_radius,0),(0,pupil_radius),(0,-pupil_radius)]:
                        target=add(L,[px,0,pz])
                        reflected=sub(target,scale(normal,2*dot(sub(target,M),normal)))
                        direction=sub(reflected,source)
                        t=dot(sub(M,source),normal)/dot(direction,normal)
                        hit=add(source,scale(direction,t)); d=sub(hit,M)
                        edge=min(p['mirror_w']/2-abs(dot(d,along)),p['mirror_h']/2-abs(d[2]))
                        margin=min(margin,edge); count+=1
                        rejected+=int(not 0<t<1 or edge<1)
        return {'width_mm':w,'height_mm':h,'lens_sample_radius_mm':pupil_radius,
                'sampled_rays':count,'minimum_mirror_edge_margin_mm':round(margin,3),
                'rays_inside_1mm_mirror_border':count-rejected,'all_inside_border':rejected==0}
    labels=check_zone(12,6,2)
    full=check_zone(21.7,10.8,2)
    path=math.dist(O,M)+math.dist(M,L)
    report={'source_sha256':hashlib.sha256((ROOT/'DETECT.scad').read_bytes()+(ROOT/'parameters.scad').read_bytes()).hexdigest(),'nominal_folded_distance_mm':path,'focus_travel_distance_mm':[path-p['oled_focus_travel'],path+p['oled_focus_travel']],
            'central_label_zone':labels,'full_screen_zone':full,
            'scope':'Finite mirror fold geometry only. Lens principal planes/profile, aberration, full housing ray bundles, eye relief, brightness, prescription lenses and readable eye box are not certified.',
            'bench_calibration_required':True}
    if not labels['all_inside_border']: raise RuntimeError('Central label rays clip the mirror: '+json.dumps(report))
    (ROOT/'OPTICAL_CHECK.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
if __name__=='__main__': main()
